# Web Comic Reader
Web Based cbr/cbz/cbt comic book reader. Written in HTML5 and Javascript (with jQuery) <br>
Demo: https://afzafri.github.io/Web-Comic-Reader/

# Screenshots
<img src="https://cloud.githubusercontent.com/assets/14824387/25302185/e8353cee-276a-11e7-9e78-d58eac26b16f.png" width="500px"/><br>
<img src="https://cloud.githubusercontent.com/assets/14824387/25302186/eb8f0064-276a-11e7-9e1d-0f4dd7f7f5bd.png" width="500px"/><br>

# Credit
- Uncompress.js: https://github.com/workhorsy/uncompress.js
- lightGallery: https://github.com/sachinchoolur/lightGallery
- jQuery: https://jquery.com/

# License
This library is under ```MIT license```, please look at the LICENSE file
